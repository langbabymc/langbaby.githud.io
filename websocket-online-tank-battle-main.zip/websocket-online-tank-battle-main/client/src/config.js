export default {
  tankSpeed: 1.5,
  bulletSpeed: 3,
  fireBreak: 1000
}
